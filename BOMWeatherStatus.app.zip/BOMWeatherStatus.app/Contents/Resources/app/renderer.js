'use strict'

window.jQuery = window.$ = require('jquery');
window.Bootstrap = require('bootstrap');
